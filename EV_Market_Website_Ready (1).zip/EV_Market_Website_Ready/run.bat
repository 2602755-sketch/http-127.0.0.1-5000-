@echo off
cd /d "%~dp0"
echo Starting EV Market Performance Analysis website...
start "" http://127.0.0.1:5000
python server.py
pause
