EV MARKET PERFORMANCE ANALYSIS WEBSITE

HOW TO START (Windows)
1. Extract this ZIP file.
2. Open the extracted folder named EV_Market_Website_Ready.
3. Double-click run.bat.
4. A black Command Prompt window will open. Keep it open.
5. Your browser should open the website at http://127.0.0.1:5000.

If Flask is not installed:
1. Open Command Prompt in this folder.
2. Run: python -m pip install -r requirements.txt
3. Double-click run.bat again.

PAGES
- Home: http://127.0.0.1:5000/
- Dashboard: http://127.0.0.1:5000/dashboard
- Story: http://127.0.0.1:5000/story

NOTE
The Dashboard and Story pages embed your Tableau Public visualizations.
An internet connection is needed to display them.
